import 'package:flutter/material.dart';
import 'home.dart';

void main(){
  runApp(
    const MaterialApp(
      home: Home(),
      debugShowCheckedModeBanner: false,
      title: "example app"
    ),
  );
}